var Alexa = require('alexa-sdk');

exports.handler = function(event, context, callback){
  var alexa = Alexa.handler(event, context);
  alexa.registerHandlers(handlers);
  alexa.execute();
}

var handlers = {

  'LaunchRequest': function() {
    this.emit(':ask', 'Welcome to the University of Michigan!' + 
	  'Would you like to hear me sing The Victors?', 
	  'Would you like for me to sing the fight song?');
  },
  'MichiganIntent': function() {
    this.emit(':tell', 'Hail! to the victors valiant!'+
      'Hail! to the conquering heroes! Hail! Hail! to Michigan the leaders and best!' +
      'Hail! to the victors valiant! Hail! to the conquering heroes!' +
      'Hail! Hail! to Michigan, the champions of the West! Go Blue!');
	this.emit(':ask', 'Would you like for me to sing it again?')
  },
  'OSUIntent': function() {
    this.emit(':tell', 'Booo OSU! Go Blue!');
  },
  'MSUIntent': function() {
    this.emit(':tell', 'Booo MSU! Go Blue!');
  },
  'PennIntent': function() {
    this.emit(':tell', 'Booo Penn State! Go Blue!');
  },
  'WisconsinIntent': function() {
    this.emit(':tell', 'Booo Wisconsin! Go Blue!');
  },
  'MinnesotaIntent': function() {
    this.emit(':tell', 'Booo Minnesota! Go Blue!');
  },
  'PurdueIntent': function() {
    this.emit(':tell', 'Booo Purdue! Go Blue!');
  },
  'RutgersIntent': function() {
    this.emit(':tell', 'Booo Rutgers! Go Blue!');
  },
  'IndianaIntent': function() {
    this.emit(':tell', 'Booo Indiana! Go Blue!');
  },
  'MarylandIntent': function() {
    this.emit(':tell', 'Booo Maryland! Go Blue!');
  },
  'NorthwesternIntent': function() {
    this.emit(':tell', 'Booo Northwestern! Go Blue!');
  },
  'IowaIntent': function() {
    this.emit(':tell', 'Booo Iowa! Go Blue!');
  },
  'NebraskaIntent': function() {
    this.emit(':tell', 'Booo Nebraska! Go Blue!');
  },
  'IllinoisIntent': function() {
    this.emit(':tell', 'Booo Illinois! Go Blue!');
  },
  'AMAZON.HelpIntent': function () {    
    this.emit(':tell', 'I can sing the Michigan fight song.' + 
	  'To hear me sing, say: Alexa, sing the Michigan fight song or ' +
	  'Alexa, sing Hail to the Victors or Alexa, sing the Victors.' + 
	  'To cancel, say Cancel.')
	this.emit(':ask', 'Would you like for me to sing the fight song?')
  },
  'AMAZON.StopIntent': function () {
     this.emit(':tell', 'Forever Go Blue!')
  },
  'AMAZON.Cancel': function () {
     this.emit(':tell', 'Forever Go Blue!')
  },
  'Unhandled': function() {
	  this.emit(':tell', 'Sorry, I dont understand.');
  },
  'SessionEndedRequest': function() {
	  this.emit(':tell', 'Go Blue!');
  }
  
};
